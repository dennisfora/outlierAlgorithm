﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Common.algoToolbox
{
    public class outlierAlgorithm
    {
        /*
             use the previous pre-defined (noOfPre) market price to calculate mean, 
             mark price, more than pre-defined diff percentage (diffpercent). as outlier(isOutlier = true)

        */
        public static int basic_denis1(ref DataTable dt, int noOfPre , double diffpercent, out string sErrMsg)
        {
            sErrMsg = "";
            try
            {

                DataTable dtTemp = new DataTable();

                Double[] aMean = null;
                int length = dt.Rows.Count;
                aMean = new Double[length];
                //assign 0 to the aMean
                //line 1 is heading , ignore
                for (int x = 0; x < aMean.Length; x++)
                {
                    aMean[x] = 0;
                }

                //calculate the mean
                for (int n = aMean.Length-1; n >= 0; n--)
                {
                    //add the price to later total
                    int count = 0;
                    for (int j = 1; j <= noOfPre && (n-j >= 0); j++,count++)
                    {
                       
                        
                        aMean[n] += dataHandle.toDouble(dt.Rows[n-j][1].ToString());
                        
                    }
                    //calculate mean
                    if (count != 0)
                        aMean[n] = aMean[n] / count;
                    else
                        aMean[n] = dataHandle.toDouble(dt.Rows[n][1].ToString());


                }


                
                DataColumn dc = new DataColumn("isOutlier");
                dc.DataType = System.Type.GetType("System.Boolean");
                dc.AllowDBNull = true;
                dc.DefaultValue = false;
                if (!dt.Columns.Contains("isOutlier"))
                dt.Columns.Add(dc);

                int k = 0;
                foreach(DataRow dr in dt.Rows)
                {
                    
                        double diff = Math.Abs(dataHandle.toDouble(dr[1].ToString()) - (double)aMean[k]);
                        double diffP = diff / aMean[k];
                        if ((diffP > (double)diffpercent) ==true)
                        {
                            dr[2] = true;
                        }
                        else
                        {
                            dr[2] = false;
                        }
                    
                    
                    k++;
                }


            }
            catch (Exception e)
            {
                sErrMsg = "basic_denis1:\n"+e.ToString();
                return 1;
            }
            return 0;
        }


    }
}

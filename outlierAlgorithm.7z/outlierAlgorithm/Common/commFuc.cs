﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using Microsoft.VisualBasic.FileIO;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Drawing;

namespace Common
{
    public class commFuc
    {
        public static int  getDataTabletFromCSVFile(string csv_file_path, out DataTable csvData, out string eErrMsg)
        {
            eErrMsg = "";
            csvData = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }
            }
            catch (Exception ex)
            {
                eErrMsg = ex.ToString();
                return 1;
            }

            return 0;
        }

        public static int plotDtOnGraph(ref Chart chart, DataTable dt, string seriesName, Color color, out string sErrMsg)
        {
            sErrMsg = "";
            try
            {

                // chartArea
                ChartArea chartArea = new ChartArea();
                chart.ChartAreas[0].Axes[0].MajorGrid.Enabled = false;//x axis
                chart.ChartAreas[0].AxisY.LabelStyle.Format = "P";
                chart.ChartAreas[0].AxisY.IsStartedFromZero = false;



                chart.ChartAreas[0].AxisX.Interval = 1;
                chart.ChartAreas[0].Axes[1].MajorGrid.Enabled = true;//y axis
                chart.ChartAreas[0].Axes[1].IsStartedFromZero = false;

                //Series
                Series series = new Series();
                series.Name = seriesName;
                
                chart.Series.Add(series);

                //Series style
                series.ChartType = SeriesChartType.Point;  // type
                series.BorderWidth = 2;
                series.Color = color;
                /*
                double[] values = { 0.2, 0, 0, 0.1, 0.2, 0.3, 0, 0, 0, 0, 0.1, 0.3, 0.2, 0.2 };
                string[] s = { "1/3/2017", "1/4/2017", "1/5/2017", "1/9/2017", "1/10/2017", "1/11/2017", "1/12/2017", "13/01/2017", "16/01/2017", "17/01/2017", "18/01/2017", "19/01/2017", "20/01/2017", "20/01/2017" };
                int x = 0;

                foreach (var v in values)
                {
                    series1.Points.AddXY(s[x], v);
                    x++;
                }
                */

                if (dt != null)
                {
                    Boolean indOn = false;
                    if (dt.Columns.Count > 2)
                    {
                        indOn = true;
                    }

                    foreach (DataRow dr in dt.Rows)
                    {
                        if (indOn && dr[2].ToString().Trim() == "True")
                        {
                            series.Color = Color.Red;
                            series.Points.AddXY(dr[0].ToString(), dr[1].ToString());
                            series.Color = color;
                        }

                        series.Points.AddXY(dr[0].ToString(), dr[1].ToString());
                    }
                }
            }
            catch (Exception e)
            {
                sErrMsg = "plotDtOnGraph\n" + e.ToString();
                return 1;
            }
            return 0;
        }

        public static void plotDtOnGraph()
        {
            throw new NotImplementedException();
        }

        public static int exportDtToCSV(DataTable dtDataTable, string strFilePath, out string sErrMsg)
        {
            sErrMsg = "";
            try
            {
                if (File.Exists(strFilePath))
                {
                    File.Delete(strFilePath);
                }


                StreamWriter sw = new StreamWriter(strFilePath, false);
                //headers    
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    sw.Write(dtDataTable.Columns[i]);
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
                foreach (DataRow dr in dtDataTable.Rows)
                {
                    for (int i = 0; i < dtDataTable.Columns.Count; i++)
                    {
                        if (!Convert.IsDBNull(dr[i]))
                        {
                            string value = dr[i].ToString();
                            if (value.Contains(','))
                            {
                                value = String.Format("\"{0}\"", value);
                                sw.Write(value);
                            }
                            else
                            {
                                sw.Write(dr[i].ToString());
                            }
                        }
                        if (i < dtDataTable.Columns.Count - 1)
                        {
                            sw.Write(",");
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception e)
            {
                sErrMsg = "exportDtToCSV\n" + e.ToString();
                return 1;
            }
            MessageBox.Show("Done!");
            return 0;

        }


        
    }
}



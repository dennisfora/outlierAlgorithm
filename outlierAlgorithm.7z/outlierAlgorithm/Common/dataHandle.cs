﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    public class dataHandle
    {
        public static Double toDouble(string s)
        {
            Double number;

            if (Double.TryParse(s, out number) == true)
                return number;
            else
                throw new Exception(s+" fail to convert double!");



        }
    }
}

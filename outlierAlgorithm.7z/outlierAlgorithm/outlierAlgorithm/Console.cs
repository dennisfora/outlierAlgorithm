﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using Common;

namespace outlierAlgorithm
{
    public partial class Console : Form
    {
        string strFilePath;
        public Console()
        {
            InitializeComponent();
        }

        private void form_load(object sender, EventArgs e)
        {
            this.textBox1.Text = "0.05";
            this.txtImportCSVPath.Text = @"C:\Users\dennischau\source\repos\outlierAlgorithm\outlierAlgorithm\bin\Debug\Outliers.csv";
            strFilePath = @"C:\Users\dennischau\source\repos\outlierAlgorithm\outlierAlgorithm\bin\Debug\";
        }

        #region event
        private void BtnImport_Click(object sender, EventArgs e)
        {
            importOriginal();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {

            showOriginal();

        }
        private void btnExport_Click(object sender, EventArgs e)
        {
            exportcsv();


        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            cal();
        }



        #endregion

        #region functions
        private void importOriginal()
        {
            string strFilePath = this.txtImportCSVPath.Text;
            DataTable dtCSV;
            string sErrMsg = "";
            if (0 != Common.commFuc.getDataTabletFromCSVFile(strFilePath, out dtCSV, out sErrMsg))
            {
                MessageBox.Show("Import CSV failed: \n" + sErrMsg);
                return;
            }

            this.dgvData.DataSource = dtCSV;

        }
        private void showOriginal()
        {
            chart.Series.Clear();
            DataTable dt = (DataTable)dgvData.DataSource;
            string sErrMsg = "";

            if (0 != Common.commFuc.plotDtOnGraph(ref chart, dt, "orignal", Color.Red, out sErrMsg))
            {
                MessageBox.Show(sErrMsg);
            }
        }
        private void showOutput()
        {
            DataTable dt = (DataTable)dgvData.DataSource;
            string sErrMsg = "";

            for (int i = dt.Rows.Count - 1; i >= 0; i--)
            {

                if (dt.Rows[i][2].ToString() == "True")
                {
                    dt.Rows.RemoveAt(i);
                }
            }


            commFuc.plotDtOnGraph(ref chart, dt, "remove-outlier", Color.Green, out sErrMsg);
        }

        private void cal()
        {
            DataTable dt = (DataTable)dgvData.DataSource;
            string sErrMsg = "";
            if (0 != Common.algoToolbox.outlierAlgorithm.basic_denis1(ref dt, 10, Common.dataHandle.toDouble(this.textBox1.Text), out sErrMsg))
            {
                MessageBox.Show(sErrMsg);
            }
        }
        /*
         * datable columns:
         col1: datetime
         col2: market price
         col3: outlier indicator
         */
        private void exportcsv()
        {

            DataTable dt = (DataTable)dgvData.DataSource;
            dt.Columns.RemoveAt(2);//the isOulier indicator

            string sErrMsg = "";
            if (0 != Common.commFuc.exportDtToCSV(dt, strFilePath + @"\output.csv", out sErrMsg))
            {
                MessageBox.Show(sErrMsg);
            }

        }
        #endregion

        private void button2_Click(object sender, EventArgs e)
        {
            showOutput();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Select file";
            dialog.InitialDirectory = ".\\";
            dialog.Filter = "csv files (*.*)|*.csv";

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                System.IO.FileInfo fInfo = new System.IO.FileInfo(dialog.FileName);

                string strFileName = fInfo.Name;

                strFilePath = fInfo.DirectoryName;



                this.txtImportCSVPath.Text = strFilePath + @"\" + strFileName; //取得檔名
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            importOriginal();
            showOriginal();
        }

       

        private void btnOutput_Click(object sender, EventArgs e)
        {
            cal();
            showOutput();
            exportcsv();
        }
    }
}
